import React from 'react'

const temporary = () => {
  return (
    <div>
      
    </div>
  )
}

export default temporary
